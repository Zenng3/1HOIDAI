const CONFIG = {
    introTitle: 'cái ghế à!',
    introDesc: `dù 1/6 hay còn gọi là quốc tế thiếu nhi đã qua nhưng m có muốn tặng quà không hãy nói cho t biết`,
    btnIntro: 'ok ',
    title: 'phải chăng mày không thích t tặng quà đúng không',
    desc: 'Phải chăng m không thích làm thiếu nhi nữa đúng không ',
    btnYes: 'ừ t muốn m không phải mất tiền ',
    btnNo: 'có chứ t vẫn muốn làm thiếu nhi',
    question:'Trên thế giới hơn 7 tỉ người mà sao m lại đòi quà t (mà quên dân số tăng lên 8 tỉ rồi) <3',
    btnReply: 'cảm ơn vì đã tiết kiệm tiền cho t',
    reply: 'cảm ơn vì đã tiết kiệm tiền cho t :)',
    mess: 't biết mà 🥰. cảm ơn m nhiều nhiều nhiều 😘😘',
    messDesc: 'hỏi lại lần cuối nhé m có thích quà không.',
    btnAccept: 'khôngggg',
    
}
